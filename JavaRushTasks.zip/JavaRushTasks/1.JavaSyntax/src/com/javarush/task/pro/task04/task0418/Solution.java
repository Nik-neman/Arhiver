package com.javarush.task.pro.task04.task0418;

import java.util.Scanner;

/* 
Стакан наполовину пуст или наполовину полон?
*/

public class Solution {
    public static void main(String[] args) {
        double glass = 0.5;
        int rez = 0;
        Scanner scanner = new Scanner(System.in);
        boolean pipl = scanner.nextBoolean();
        if (pipl == true) 
        {
            rez = (int) Math.ceil(glass);
        }
        else
        {
             rez = (int) Math.floor(glass);
        }
        System.out.println(rez);//напишите тут ваш код

    }
}
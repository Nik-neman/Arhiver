package com.javarush.task.pro.task04.task0402;

import java.util.Scanner;

/* 
Все любят Мамбу
*/

public class Solution {
    public static void main(String[] args) {
        String text = " любит меня.";
        Scanner console = new Scanner(System.in);
        String Name = console.nextLine();
        int a = 10;
        while (a != 0){
        System.out.println(Name + text);
        a--;//напишите тут ваш код
        }
    }
}

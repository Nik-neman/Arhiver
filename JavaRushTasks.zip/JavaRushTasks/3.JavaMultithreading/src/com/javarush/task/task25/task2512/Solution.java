package com.javarush.task.task25.task2512;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/* 
Живем своим умом
*/

public class Solution implements Thread.UncaughtExceptionHandler {

    @Override
    public void uncaughtException(Thread t, Throwable e)
    {
        t.interrupt();
        if (e.getCause() != null)
        {
            uncaughtException(t, e.getCause());
        }
        System.out.println(e);
    }


//        Throwable a = e;
//        List<Throwable> list = new ArrayList<>();
//        do {
//            list.add(a);
//            a = e.getCause();
//
//        } while (a!= null);
//        for (int i = list.size(); i > 0; i--) {
//
//            System.out.println(list.get(i));
//        }
//    }
    public void printE(Throwable e){
        if (e.getCause()!=null){
            printE(e.getCause());
            System.out.println(e);
        }
    }



    public static void main(String[] args) {
    }
}

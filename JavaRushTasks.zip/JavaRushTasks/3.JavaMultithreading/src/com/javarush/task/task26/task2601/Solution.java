package com.javarush.task.task26.task2601;

import java.util.*;
import java.util.regex.Matcher;

/* 
Почитать в инете про медиану выборки
*/

public class Solution {

    public static void main(String[] args) {
        Integer[] array = {13, 8, 15, 5, 17
        };
        Solution.sort(array).toString();
        for (Integer i: array) {
//            System.out.print(i+ ", ");
        }

    }

    public static Integer[] sort(Integer[] array) {
        //implement logic here
        Arrays.sort(array);
        double mediana = 0;
        if (array.length%2 == 0) {
            mediana = (array[array.length/2] + array[array.length/2 -1])/2;
        } else {
            mediana =   array[(array.length  -1) /2];
        }

//        double mediana = 0;
//        for (Integer i: array){
//           mediana += i; }
//        mediana = mediana/array.length;
//        double razn = Double.MAX_VALUE;
//        Integer med = 0;
//        for (Integer j: array){
//            if(Math.abs(mediana - j)< razn) {
//                razn = Math.abs(mediana - j);
//                med = j;
//            }
//        }
//            mediana = med;
//        System.out.println(mediana);
        class Namber implements Comparable<Namber> {
            Integer kay;
            Integer value;

            public Namber(Integer kay, Integer value) {
                this.kay = kay;
                this.value = value;
            }
            @Override
            public int compareTo(Namber o) {
                return this.kay - o.kay;
            }
        }
        List<Namber> list = new ArrayList<>();
        Arrays.sort(array);
        for (int i: array){
            int key = (int) Math.round(Math.abs(mediana - i));
            list.add(new Namber(key, i));
        }
//        Comparator<Namber> comparator = new Comparator<Namber>() {
//            @Override
//            public int compare(Namber o1, Namber o2) {
//                return o1.kay - o2.kay;
//            }
//        };
        Collections.sort(list);
        for (int i = 0; i < list.size(); i++){
            array[i] = list.get(i).value;
        }
        return array;
    }
}

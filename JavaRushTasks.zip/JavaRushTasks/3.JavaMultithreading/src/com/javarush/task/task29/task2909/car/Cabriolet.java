package com.javarush.task.task29.task2909.car;

public class Cabriolet extends Car {
    int numberOfPassengers;
    public Cabriolet(int numberOfPassengers) {
        super(CABRIOLET, numberOfPassengers);
        this.numberOfPassengers = numberOfPassengers;
    }

    @Override
    public int getMaxSpeed() {
        return Car.MAX_CABRIOLET_SPEED;
    }
}

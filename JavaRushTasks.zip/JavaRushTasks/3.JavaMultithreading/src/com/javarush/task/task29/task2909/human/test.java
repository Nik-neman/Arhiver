package com.javarush.task.task29.task2909.human;


public class test {
    public static void main(String[] args) {
        new Human("Men", 22);
        new Soldier("Sol", 22);
        System.out.println("OK");
    }
}
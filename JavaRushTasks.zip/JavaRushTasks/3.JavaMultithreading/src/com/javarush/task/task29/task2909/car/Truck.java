package com.javarush.task.task29.task2909.car;

public class Truck extends Car {
    int numberOfPassengers;
    public Truck(int numberOfPassengers) {
        super(TRUCK, numberOfPassengers);
        this.numberOfPassengers = numberOfPassengers;
    }

    @Override
    public int getMaxSpeed() {
        return MAX_TRUCK_SPEED;
    }
}
